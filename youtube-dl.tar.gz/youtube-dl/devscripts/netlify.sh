#!/bin/bash
./devscripts/git-dumb-cdn.sh netlify

