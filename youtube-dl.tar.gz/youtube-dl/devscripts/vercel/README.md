# Setting up Vercel

- Build command: empty
- Output Directory: empty
- Root Directory: `devscripts/vercel/`
