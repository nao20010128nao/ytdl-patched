from __future__ import unicode_literals

from .peertube import PeerTubeIE

__all__ = ['PeerTubeIE']
